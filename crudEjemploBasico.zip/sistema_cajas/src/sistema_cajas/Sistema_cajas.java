/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistema_cajas;

import java.util.Scanner;

/**
 *
 * @author brian
 */
public class Sistema_cajas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        Caja caja = new Caja();
        System.out.println("Bienvenido");
        int op = 0;
        do {
            System.out.println("-Ingresa un numero del menu-");
            System.out.println("1.-Agregar producto a la caja");        //CREATE 
            System.out.println("2.-ver productos ingresados");          //READ
            System.out.println("3.-Actualizar un producto ingresado");  //UPDATE    CRUD
            System.out.println("4.-Eliminar producto ingresado");       //DELETE
            System.out.println("5.-Salir del programa");
            op = leer.nextInt();
            switch (op) {
                case 1:
                    caja.agregarProducto();
                    break;
                case 2:
                    caja.verProductos();
                    break;
                case 3:
                    caja.actualizarProducto();
                    break;
                case 4:
                    caja.eliminarProducto();
                    break;
                case 5:
                    System.out.println("Gracias por usar el programa!\nCreado por Brx2b 2024.");
                    break;
            }
        } while (op != 5);
    }

}
