/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_cajas;

/**
 *
 * @author brian
 */
public class Producto {

    private String nombre;
    private String clasificacion;
    private int peso;
    private int id;

    public Producto(String nombre, String clasificacion, int peso, int id) {
        this.nombre = nombre;
        this.clasificacion = clasificacion;
        this.peso = peso;
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getClasificacion() {
        return clasificacion;
    }

    public void setClasificacion(String clasificacion) {
        this.clasificacion = clasificacion;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Nombre = " + nombre + "\nClasificacion = " + clasificacion + "\nPeso = " + peso + "\nId = " + id;
    }

}
