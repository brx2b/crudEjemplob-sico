/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_cajas;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author brian
 */
public class Caja {

    ArrayList<Producto> productosCaja = new ArrayList<>();
    Scanner leer = new Scanner(System.in);

    public void agregarProducto() {
        System.out.println("Ingresa nombre ");
        String nom = leer.nextLine();
        if (nom.isEmpty()) {
            nom = leer.nextLine();
        }
        System.out.println("Ingresa clasificacion ");
        String Clasifi = leer.nextLine();
        System.out.println("Ingresa peso ");
        int peso = leer.nextInt();
        System.out.println("Ingresa id");
        int id = leer.nextInt();
        Producto productoNuevo = new Producto(nom, Clasifi, peso, id);
        productosCaja.add(productoNuevo);
        for (int i = 0; i < productosCaja.size(); i++) {
            if (id == productosCaja.get(i).getId()) {
                System.out.println("Se agrego correctamente");
            } else {
                System.out.println("Hubo un problema al agregar el producto");
            }
        }
    }

    public void verProductos() {
        if (productosCaja.isEmpty()) {
            System.out.println("No hay productos registrados");
        } else {
            for (int i = 0; i < productosCaja.size(); i++) {
                System.out.println("--PRODUCTO " + productosCaja.get(i).getNombre() + "--");
                System.out.println(productosCaja.get(i));
            }
        }

    }

    public void actualizarProducto() {
        if (productosCaja.isEmpty()) {
            System.out.println("No hay productos registrados");
        } else {
            System.out.println("Ingresa id del producto a actualizar");
            int idAct = leer.nextInt();
            for (int i = 0; i < productosCaja.size(); i++) {
                if (productosCaja.get(i).getId() == idAct) {
                    System.out.println("Ingresa nombre ");
                    String nom = leer.nextLine();
                    if (nom.isEmpty()) {
                        nom = leer.nextLine();
                    }
                    productosCaja.get(i).setNombre(nom);
                    System.out.println("Ingresa clasificacion ");
                    String Clasifi = leer.nextLine();
                    productosCaja.get(i).setClasificacion(Clasifi);
                    System.out.println("Ingresa peso ");
                    int peso = leer.nextInt();
                    productosCaja.get(i).setPeso(peso);
                    System.out.println("Ingresa id");
                    int id = leer.nextInt();
                    productosCaja.get(i).setId(id);
                    System.out.println("Producto actualizado!");
                }
            }

        }

    }

    public void eliminarProducto() {
        if (productosCaja.isEmpty()) {
            System.out.println("No hay productos registrados");
        } else {
            System.out.println("Ingresa id de producto a eliminar");
            int idElim = leer.nextInt();
            for (int i = 0; i < productosCaja.size(); i++) {
                if (productosCaja.get(i).getId() == idElim) {
                    productosCaja.remove(i);
                    System.out.println("Producto eliminado!");
                } else {
                    System.out.println("No se encontro id asociado");
                }
            }
        }
    }
}
